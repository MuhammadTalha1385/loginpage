import React from 'react'

function NoPage() {
  return (
    <>
      <h1>Page Not Found:404</h1>
    </>
  )
}

export default NoPage